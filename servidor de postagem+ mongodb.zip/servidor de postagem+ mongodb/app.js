var express = require('express')

var app = express();

var color = require('colors')

app.set('view engine', 'ejs');

app.use(express.urlencoded({ extended: true }));

app.use(express.static('public'));

const { MongoClient } = require('mongodb');

const uri = 'mongodb+srv://koga:eu@cluster0.cdl7opi.mongodb.net/?appName=Cluster0'

const client = new MongoClient(uri);

client.connect().then(()=>{
    console.log("Banco OK")
    app.listen(3000, ()=> {

        console.log('tudo certo'.green)

    })


})

app.get('/', (req,res)=>{

    res.render('menu')

})

app.post('/post', (req,res)=>{

    res.render('post')
})

app.post('/criado', async (req,res)=>{

    const novoPost = {

        titulo : req.body.titulo,

        resumo : req.body.resumo,

        conteudo : req.body.conteudo

    }

    const db = client.db('midia')

    await db.collection('posts').insertOne(novoPost)

    console.log('post salvo no banco'.green)

    res.send("Postagem criada com sucesso! <a href='/'>Voltar ao menu</a>");


    res.render('menu', { novoPost })


})

